// Authentication Module

class Auth {
    constructor() {
        this.token = localStorage.getItem('auth_token');
        this.user = JSON.parse(localStorage.getItem('user') || 'null');
        this.isAuthenticated = !!this.token;
    }

    async login(email, password) {
        try {
            // Use MockAPI for development
            const response = await MockAPI.login(email, password);

            if (response.success) {
                this.token = response.token;
                this.user = response.user;
                this.isAuthenticated = true;

                localStorage.setItem('auth_token', this.token);
                localStorage.setItem('user', JSON.stringify(this.user));

                // Dispatch login event
                this.dispatchEvent('login', this.user);

                return { success: true, user: this.user };
            }
        } catch (error) {
            console.error('Login error:', error);
            return { success: false, error: error.message };
        }
    }

    async logout() {
        try {
            await MockAPI.logout();
        } catch (error) {
            console.error('Logout error:', error);
        } finally {
            this.token = null;
            this.user = null;
            this.isAuthenticated = false;

            localStorage.removeItem('auth_token');
            localStorage.removeItem('user');

            this.dispatchEvent('logout');

            // Redirect to login page
            window.location.href = 'login.html';
        }
    }

    getUser() {
        return this.user;
    }

    getToken() {
        return this.token;
    }

    hasRole(role) {
        return this.user && this.user.role === role;
    }

    isAdmin() {
        return this.hasRole('admin');
    }

    isTeacher() {
        return this.hasRole('teacher');
    }

    isStudent() {
        return this.hasRole('student');
    }

    requireAuth() {
        if (!this.isAuthenticated) {
            window.location.href = 'login.html';
            return false;
        }
        return true;
    }

    requireRole(role) {
        if (!this.requireAuth()) return false;
        if (!this.hasRole(role)) {
            window.location.href = 'dashboard.html';
            return false;
        }
        return true;
    }

    dispatchEvent(eventName, data = null) {
        const event = new CustomEvent(`auth:${eventName}`, { detail: data });
        window.dispatchEvent(event);
    }

    on(eventName, callback) {
        window.addEventListener(`auth:${eventName}`, callback);
    }

    off(eventName, callback) {
        window.removeEventListener(`auth:${eventName}`, callback);
    }
}

// Initialize auth instance
const auth = new Auth();

// Auth guard for protected pages
if (window.location.pathname.includes('dashboard.html')) {
    if (!auth.requireAuth()) {
        window.location.href = 'login.html';
    }
}

// Export auth instance
if (typeof module !== 'undefined' && module.exports) {
    module.exports = auth;
}