// Dashboard JavaScript

document.addEventListener('DOMContentLoaded', () => {
    // Check authentication
    if (!auth.isAuthenticated) {
        window.location.href = 'login.html';
        return;
    }

    // Load dashboard data
    loadDashboardData();

    // Initialize charts
    initCharts();

    // Load recent activities
    loadRecentActivities();

    // Setup logout button
    setupLogout();
});

async function loadDashboardData() {
    const user = auth.getUser();

    // Update welcome message
    const welcomeEl = document.querySelector('.welcome-message');
    if (welcomeEl) {
        welcomeEl.textContent = `Welcome back, ${user.name}!`;
    }

    // Load stats based on role
    if (auth.isAdmin()) {
        await loadAdminStats();
    } else if (auth.isTeacher()) {
        await loadTeacherStats();
    } else if (auth.isStudent()) {
        await loadStudentStats();
    }
}

async function loadAdminStats() {
    try {
        // Simulate API calls
        const students = await MockAPI.getStudents();
        const notices = await MockAPI.getNotices();

        // Update stats
        document.getElementById('totalStudents').textContent = students.length;
        document.getElementById('totalTeachers').textContent = '25';
        document.getElementById('totalClasses').textContent = '12';
        document.getElementById('attendanceRate').textContent = '94%';

        // Update recent notices
        const noticesList = document.getElementById('recentNotices');
        if (noticesList) {
            noticesList.innerHTML = notices.slice(0, 5).map(notice => `
                <div class="notice-item">
                    <div class="notice-title">${notice.title}</div>
                    <div class="notice-date">${formatDate(notice.date)}</div>
                </div>
            `).join('');
        }
    } catch (error) {
        console.error('Error loading admin stats:', error);
    }
}

async function loadTeacherStats() {
    try {
        // Teacher specific stats
        document.getElementById('myClasses').textContent = '3';
        document.getElementById('totalStudents').textContent = '120';
        document.getElementById('pendingAssignments').textContent = '15';
        document.getElementById('attendanceToday').textContent = '85%';
    } catch (error) {
        console.error('Error loading teacher stats:', error);
    }
}

async function loadStudentStats() {
    try {
        // Student specific stats
        document.getElementById('attendance').textContent = '92%';
        document.getElementById('averageMarks').textContent = '85%';
        document.getElementById('rank').textContent = '15';
        document.getElementById('pendingAssignments').textContent = '3';
    } catch (error) {
        console.error('Error loading student stats:', error);
    }
}

function initCharts() {
    // Attendance chart
    const attendanceCtx = document.getElementById('attendanceChart');
    if (attendanceCtx) {
        new Chart(attendanceCtx, {
            type: 'line',
            data: {
                labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
                datasets: [{
                    label: 'Attendance %',
                    data: [92, 88, 94, 96],
                    borderColor: '#4a6fa5',
                    backgroundColor: 'rgba(74, 111, 165, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });
    }

    // Performance chart
    const performanceCtx = document.getElementById('performanceChart');
    if (performanceCtx) {
        new Chart(performanceCtx, {
            type: 'bar',
            data: {
                labels: ['Math', 'Science', 'English', 'History', 'Computer'],
                datasets: [{
                    label: 'Marks %',
                    data: [85, 78, 92, 88, 95],
                    backgroundColor: '#ff6b6b',
                    borderRadius: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });
    }
}

async function loadRecentActivities() {
    const activities = [
        { type: 'assignment', message: 'Math assignment submitted', time: '2 hours ago' },
        { type: 'attendance', message: 'Marked present for today', time: '4 hours ago' },
        { type: 'notice', message: 'New notice from principal', time: '1 day ago' },
        { type: 'exam', message: 'Exam schedule released', time: '2 days ago' }
    ];

    const activitiesList = document.getElementById('recentActivities');
    if (activitiesList) {
        activitiesList.innerHTML = activities.map(activity => `
            <div class="activity-item">
                <div class="activity-icon">
                    <i class="fas fa-${getActivityIcon(activity.type)}"></i>
                </div>
                <div class="activity-content">
                    <p>${activity.message}</p>
                    <span class="activity-time">${activity.time}</span>
                </div>
            </div>
        `).join('');
    }
}

function getActivityIcon(type) {
    const icons = {
        assignment: 'book',
        attendance: 'calendar-check',
        notice: 'bell',
        exam: 'file-alt'
    };
    return icons[type] || 'info-circle';
}

function setupLogout() {
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            auth.logout();
        });
    }
}