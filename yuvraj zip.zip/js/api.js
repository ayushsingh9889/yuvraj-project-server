// API Configuration
const API_BASE_URL = 'https://api.takshila.edu/api/v1';

// API endpoints
const API_ENDPOINTS = {
    LOGIN: '/auth/login',
    REGISTER: '/auth/register',
    LOGOUT: '/auth/logout',
    STUDENTS: '/students',
    TEACHERS: '/teachers',
    COURSES: '/courses',
    ATTENDANCE: '/attendance',
    MARKS: '/marks',
    NOTICES: '/notices',
    EVENTS: '/events',
    GALLERY: '/gallery'
};

// API Request helper
async function apiRequest(endpoint, method = 'GET', data = null, headers = {}) {
    const token = localStorage.getItem('auth_token');

    const defaultHeaders = {
        'Content-Type': 'application/json',
        ...headers
    };

    if (token) {
        defaultHeaders['Authorization'] = `Bearer ${token}`;
    }

    const config = {
        method,
        headers: defaultHeaders
    };

    if (data && method !== 'GET') {
        config.body = JSON.stringify(data);
    }

    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.message || 'API request failed');
        }

        return result;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Auth API
const AuthAPI = {
    login: async (email, password) => {
        return apiRequest(API_ENDPOINTS.LOGIN, 'POST', { email, password });
    },

    register: async (userData) => {
        return apiRequest(API_ENDPOINTS.REGISTER, 'POST', userData);
    },

    logout: async () => {
        return apiRequest(API_ENDPOINTS.LOGOUT, 'POST');
    },

    getProfile: async () => {
        return apiRequest('/auth/profile');
    }
};

// Student API
const StudentAPI = {
    getAll: async () => {
        return apiRequest(API_ENDPOINTS.STUDENTS);
    },

    getById: async (id) => {
        return apiRequest(`${API_ENDPOINTS.STUDENTS}/${id}`);
    },

    create: async (data) => {
        return apiRequest(API_ENDPOINTS.STUDENTS, 'POST', data);
    },

    update: async (id, data) => {
        return apiRequest(`${API_ENDPOINTS.STUDENTS}/${id}`, 'PUT', data);
    },

    delete: async (id) => {
        return apiRequest(`${API_ENDPOINTS.STUDENTS}/${id}`, 'DELETE');
    },

    getAttendance: async (id) => {
        return apiRequest(`${API_ENDPOINTS.STUDENTS}/${id}/attendance`);
    },

    getMarks: async (id) => {
        return apiRequest(`${API_ENDPOINTS.STUDENTS}/${id}/marks`);
    }
};

// Teacher API
const TeacherAPI = {
    getAll: async () => {
        return apiRequest(API_ENDPOINTS.TEACHERS);
    },

    getById: async (id) => {
        return apiRequest(`${API_ENDPOINTS.TEACHERS}/${id}`);
    },

    getClasses: async (id) => {
        return apiRequest(`${API_ENDPOINTS.TEACHERS}/${id}/classes`);
    }
};

// Course API
const CourseAPI = {
    getAll: async () => {
        return apiRequest(API_ENDPOINTS.COURSES);
    },

    getById: async (id) => {
        return apiRequest(`${API_ENDPOINTS.COURSES}/${id}`);
    },

    getEnrollments: async (id) => {
        return apiRequest(`${API_ENDPOINTS.COURSES}/${id}/enrollments`);
    }
};

// Notice API
const NoticeAPI = {
    getAll: async () => {
        return apiRequest(API_ENDPOINTS.NOTICES);
    },

    getLatest: async (limit = 5) => {
        return apiRequest(`${API_ENDPOINTS.NOTICES}/latest?limit=${limit}`);
    },

    create: async (data) => {
        return apiRequest(API_ENDPOINTS.NOTICES, 'POST', data);
    }
};

// Event API
const EventAPI = {
    getAll: async () => {
        return apiRequest(API_ENDPOINTS.EVENTS);
    },

    getUpcoming: async () => {
        return apiRequest(`${API_ENDPOINTS.EVENTS}/upcoming`);
    },

    register: async (eventId, userId) => {
        return apiRequest(`${API_ENDPOINTS.EVENTS}/${eventId}/register`, 'POST', { userId });
    }
};

// Gallery API
const GalleryAPI = {
    getAll: async () => {
        return apiRequest(API_ENDPOINTS.GALLERY);
    },

    getByCategory: async (category) => {
        return apiRequest(`${API_ENDPOINTS.GALLERY}/category/${category}`);
    }
};

// Mock API for development (when backend not ready)
const MockAPI = {
    simulateDelay: () => new Promise(resolve => setTimeout(resolve, 500)),

    login: async (email, password) => {
        await MockAPI.simulateDelay();
        if (email === 'admin@takshila.edu' && password === 'admin123') {
            return {
                success: true,
                token: 'mock_jwt_token',
                user: {
                    id: 1,
                    name: 'Admin User',
                    email: 'admin@takshila.edu',
                    role: 'admin'
                }
            };
        }
        throw new Error('Invalid credentials');
    },

    getStudents: async () => {
        await MockAPI.simulateDelay();
        return [
            { id: 1, name: 'John Doe', class: '10A', rollNo: '1001', attendance: 95, marks: 85 },
            { id: 2, name: 'Jane Smith', class: '10A', rollNo: '1002', attendance: 92, marks: 88 },
            { id: 3, name: 'Mike Johnson', class: '10B', rollNo: '1003', attendance: 88, marks: 82 }
        ];
    },

    getNotices: async () => {
        await MockAPI.simulateDelay();
        return [
            { id: 1, title: 'Holiday Notice', date: '2024-03-25', content: 'School will remain closed on March 26th for Holi.' },
            { id: 2, title: 'Parent-Teacher Meeting', date: '2024-03-28', content: 'PTM scheduled for March 30th.' },
            { id: 3, title: 'Exam Schedule', date: '2024-03-20', content: 'Final exams will start from April 5th.' }
        ];
    }
};

// Export APIs
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        AuthAPI,
        StudentAPI,
        TeacherAPI,
        CourseAPI,
        NoticeAPI,
        EventAPI,
        GalleryAPI,
        MockAPI
    };
}